import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EmpAddEditComponent } from './emp-add-edit/emp-add-edit.component';
import { UsersService } from './users.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DialogRef } from '@angular/cdk/dialog';
import { EmployeeData } from './users.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  displayedColumns: string[] = ['id','name', 'username', 'email', 'action'];
  dataSource !: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private _dialog:MatDialog, 
    private _empService: UsersService
    ){}

    ngOnInit(): void {
      this.getUsersList() ;  
     
    }

  openAddEditEmpForm(){
   const dialogRef= this._dialog.open(EmpAddEditComponent,{width: '250px',});
   dialogRef.afterClosed().subscribe({
    next:(val)=>{
      if(val){
        this.getUsersList();
        console.log('data loaded')
      }
    }
   })

   
   
  }
  getUsersList(){
    this._empService.getUsersList().subscribe({
    next:(res)=>{
      this.dataSource=new MatTableDataSource(res);
      this.dataSource.sort=this.sort;
      this.dataSource.paginator=this.paginator;
    },
    error: console.log,
    });
  }    

  deleteUsersList(id: number){
    console.log('id', id)
    this._empService.deleteUsersList(id).subscribe(val=>{
      this.getUsersList();
      // next(val){ 
      //   if(val){
      //     // this.getUsersList();
      //   }
      // },
      // // next:(_res)=>{
      // //   alert('delete successfully');
      // //   this.getUsersList();
      // //   this._dialog
      // // },
      // error: console.log
      
    });
  }
  
  openEditEmpForm( data: any){
    this._dialog.open(EmpAddEditComponent,
       {width: '250px', data,});
   
}
}
