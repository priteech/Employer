import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UsersService } from '../users.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Dialog } from '@angular/cdk/dialog';


@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.css']
})
export class EmpAddEditComponent {
empForm: FormGroup;
constructor(
  private _fb: FormBuilder, 
  private _empService: UsersService, 
  private _dialogRef:MatDialogRef<EmpAddEditComponent>,
  @Inject(MAT_DIALOG_DATA) private data:any
  
  ){
  this.empForm =this._fb.group({
    name:'',
    username:'',
    email:'',
    action:'',

  });
}
onFormSubmit(){
  if (this.empForm.valid){
    this._empService.addUsers(this.empForm.value).subscribe({
      next: (val: any)=>{
        alert('added Successfully');
        this._dialogRef.close(true);
      },
      error: (err: any)=>{
        console.log(err);

      },
      
    })
  
  }
}
}

